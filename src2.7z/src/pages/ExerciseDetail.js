import React from 'react'

const ExerciseDetail = () => {
  return (
    <div>ExerciseDetail</div>
  )
}

export default ExerciseDetail