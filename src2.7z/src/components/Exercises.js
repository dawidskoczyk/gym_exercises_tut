import React from 'react'

const Exercises = () => {
  return (
    <div>Exercises</div>
  )
}

export default Exercises