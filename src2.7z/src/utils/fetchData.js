export const exerciseOptions = {
    method: 'GET',
    
    headers: {
      'x-rapidapi-key': '2c56f96d69msh4504ff16d212308p17ef9djsn2662a2c28e9e',
      'x-rapidapi-host': 'exercisedb.p.rapidapi.com'
    }
};


export const fetchData = async (url, options) =>{
    const response = await fetch(url, options);
    const data = await response.json();

    return data;
} 